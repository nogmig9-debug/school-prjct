
  # Школьный проект о нейросетях

  This is a code bundle for Школьный проект о нейросетях. The original project is available at https://www.figma.com/design/mjcKlmoDlyVNsudLhqAXXa/%D0%A8%D0%BA%D0%BE%D0%BB%D1%8C%D0%BD%D1%8B%D0%B9-%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82-%D0%BE-%D0%BD%D0%B5%D0%B9%D1%80%D0%BE%D1%81%D0%B5%D1%82%D1%8F%D1%85.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  